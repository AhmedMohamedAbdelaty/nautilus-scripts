#!/bin/bash

script-worker copy $NAUTILUS_SCRIPT_SELECTED_URIS
