import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'nautilus-copy-path'))
from nautilus_copy_path import NautilusCopyPath
