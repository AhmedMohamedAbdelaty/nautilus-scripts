No files here? 

To activate automatic mortem.txt archivising, please edit the doomrl.ini file and set MORTEMARCHIVE = True;