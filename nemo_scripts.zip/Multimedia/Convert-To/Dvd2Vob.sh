#!/bin/bash

# requires vobcopy: sudo apt-get install vobcopy
vobcopy -i /dev/dvd -o ~/ -l
