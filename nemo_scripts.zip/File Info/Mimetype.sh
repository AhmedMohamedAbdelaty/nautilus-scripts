#!/bin/sh
# Copyright (C) Sept 13, 2001 Shane Mueller <smueller@umich.edu>
# http://g-scripts.sourceforge.net
# Released into the public domain.
#
for arg
do
 
filetype=$(file -i "$arg")

  gdialog --title "File-Type Determinator" --msgbox "File $filetype" 200 200

done
