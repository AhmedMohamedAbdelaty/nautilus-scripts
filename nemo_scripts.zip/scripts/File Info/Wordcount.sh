#!/bin/sh
a=$(wc -w "$@")
gdialog --backtitle "Word Count Script"  --msgbox "Words: $a" 25 20 
