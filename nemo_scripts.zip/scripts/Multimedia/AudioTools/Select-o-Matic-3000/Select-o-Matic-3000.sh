#!/bin/bash

/home/$USER/.gnome2/nemo-scripts/Multimedia/AudioTools/Select-o-Matic-3000/.som3000
