#!/bin/bash
terminator
