#!/bin/sh
#This script opens the selected file in ghex--a hex editor
#It will only open a single file
ghex $@