#!/usr/bin/env bash
zenity --info --text "Files Deleted."
rm *~
rm .*~
rm *.old
rm *.bak
rm *.OLD
rm *.BAK
