#!/bin/sh
sh $@