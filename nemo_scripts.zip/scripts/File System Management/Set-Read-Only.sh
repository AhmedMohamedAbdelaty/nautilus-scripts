#!/bin/sh
# set_read_only
# Sets selected files as executable
# looping required for multiple filenames with spaces
for arg
do
 chmod ugo-w "$arg"
done

