#!/usr/bin/python
# PDF to Postscript - converts a PDF file to Postcript
# by invoking pdf2ps
# Christopher Culver <christopher_culver@yahoo.com>

from os import execvp
from sys import argv

pdf_file = []
pdf_file.append(argv[1])
execvp('pdf2ps', ['pdf2ps']+pdf_file)
