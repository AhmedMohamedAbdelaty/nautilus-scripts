#!/bin/bash
chown -R root:root "$1"
chmod 700 "$1"
