#!/bin/bash

gksudo gedit $NAUTILUS_SCRIPT_SELECTED_URIS
