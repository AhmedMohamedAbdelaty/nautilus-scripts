#!/bin/sh
set -eu

cd $HOME/.gnome2/nemo-scripts/Games/.doomrl
gnome-terminal --geometry=80x25  -e ./doomrl
