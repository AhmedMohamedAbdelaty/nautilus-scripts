#!/bin/sh
# set_exec
# Sets selected files as executable
# looping required for multiple filenames with spaces
for arg
do
 chmod u+x "$arg"
done