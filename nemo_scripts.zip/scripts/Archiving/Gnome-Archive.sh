#!/bin/sh
##This invokes the Gnome Archiver (meatgrinder) with the selected files
##meat-grinder is a gnome-base graphical tar.gz creator.
meat-grinder $@
