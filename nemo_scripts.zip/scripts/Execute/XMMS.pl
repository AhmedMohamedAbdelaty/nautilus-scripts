#!/usr/bin/perl

my @mp3list = @ARGV;
exec 'xmms', reverse (@mp3list);