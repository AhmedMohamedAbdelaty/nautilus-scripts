#!/bin/bash

gedit $NEMO_SCRIPT_SELECTED_URIS

