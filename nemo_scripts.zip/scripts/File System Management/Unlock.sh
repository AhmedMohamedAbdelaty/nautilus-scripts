#!/bin/bash
chmod -R 777 "$1"
chown -R $USER:$USER "$1"
