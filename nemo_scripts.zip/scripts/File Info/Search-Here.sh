#!/bin/sh
# From Johnathan Bailes
# This script opens a gnome-search-tool in the directory you select.
#
# Distributed under the terms of GNU GPL version 2 or later
#
# Install in your ~/Nautilus/scripts directory.
# You need to be running Nautilus 1.0.3+ to use scripts.

cd $NAUTILUS_SCRIPT_CURRENT_URI
exec gnome-search-tool
