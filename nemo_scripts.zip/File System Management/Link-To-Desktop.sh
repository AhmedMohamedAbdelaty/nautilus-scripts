#!/bin/bash

script-worker link_to_xdg $NAUTILUS_SCRIPT_SELECTED_URIS XDG_DESKTOP_DIR
