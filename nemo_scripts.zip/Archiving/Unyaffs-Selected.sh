#!/bin/bash
mkdir "unyaffs-$@"
cd "unyaffs-$@"
unyaffs ../"$@"
