#!/bin/sh
#This script opens the selected file(s) in xemacs
gvim $@