#!/bin/sh
#Linker...Creates a link into your home directory
# With thanks to Doug Nordwall
for arg 
do
 ln -s $PWD/$arg ~/$arg
done