No files here? 

Press F10 during the game to do screenshots!