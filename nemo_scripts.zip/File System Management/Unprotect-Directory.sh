#!/bin/bash
gksu "unlock '$1'"
